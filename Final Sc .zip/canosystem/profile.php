<?php
require_once __DIR__ . '/config/database.php';
initSession(); requireLogin();
$db=getDB(); $stmt=$db->prepare("SELECT * FROM users WHERE id=:id"); $stmt->execute([':id'=>$_SESSION['user_id']]); $user=$stmt->fetch();
if(!$user){session_destroy();header('Location: /index.php');exit;}
$csrf=generateCSRFToken();
$premiumText='Sınırsız (Free)';
if($user['user_type']==='admin')$premiumText='Sınırsız (Admin)';
elseif($user['premium_until'])$premiumText=date('d.m.Y',strtotime($user['premium_until']));
$badgeClass=$user['user_type'];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>Profil - CANO SYSTEM</title>
    <link rel="icon" href="/assets/logo.jpg" type="image/jpeg">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="page-loader" id="pageLoader"><div style="text-align:center;"><div class="loader-spinner"></div><div class="loader-text">CANO SYSTEM</div></div></div>
    <?php include __DIR__.'/includes/sidebar.php'; ?>
    <?php include __DIR__.'/includes/header.php'; ?>
    <main class="main-content" id="mainContent">
        <div class="content-inner fade-up" style="max-width:600px;">
            <h2 style="font-size:20px;margin-bottom:20px;">Profil</h2>
            <div class="profile-header">
                <div class="profile-avatar">👤</div>
                <div class="profile-name">
                    <?=sanitize($user['username'])?>
                    <svg class="verified-tick" viewBox="0 0 22 22" width="18" height="18"><path d="M20.396 11c0-.795-.613-1.478-1.404-1.65-.23-1.19-.81-2.24-1.66-3.09-.51-.51-1.09-.92-1.73-1.2C15.3 4.08 14.66 3 13.7 3c-.74 0-1.39.37-1.7.94-.31-.57-.96-.94-1.7-.94-.96 0-1.6 1.08-1.9 2.06-.64.28-1.22.69-1.73 1.2-.85.85-1.43 1.9-1.66 3.09-.79.17-1.4.86-1.4 1.65 0 .8.63 1.49 1.42 1.65.24 1.18.82 2.23 1.66 3.07.51.51 1.09.92 1.73 1.2.3.98.94 2.06 1.9 2.06.74 0 1.39-.37 1.7-.94.31.57.96.94 1.7.94.96 0 1.6-1.08 1.9-2.06.64-.28 1.22-.69 1.73-1.2.84-.84 1.42-1.89 1.66-3.07.79-.16 1.42-.85 1.42-1.65z" fill="#1DA1F2"/><path d="M9.64 12.85l-2.05-2.05 1.06-1.06.99.99 3.15-3.15 1.06 1.06-4.21 4.21z" fill="#fff"/></svg>
                </div>
                <span class="sidebar-badge <?=$badgeClass?>"><?=strtoupper($user['user_type'])?></span>
            </div>
            <div class="card" style="margin-bottom:14px;">
                <h3 style="color:var(--text3);font-size:10px;font-weight:700;letter-spacing:2px;margin-bottom:12px;">HESAP BİLGİLERİ</h3>
                <div class="info-table">
                    <div class="info-row"><span class="info-label">Kullanıcı Adı</span><span class="info-value"><?=sanitize($user['username'])?></span></div>
                    <div class="info-row"><span class="info-label">Email</span><span class="info-value"><?=sanitize($user['email'])?></span></div>
                    <div class="info-row"><span class="info-label">Üyelik</span><span class="info-value"><?=ucfirst($user['user_type'])?></span></div>
                    <div class="info-row"><span class="info-label">Premium Bitiş</span><span class="info-value"><?=$premiumText?></span></div>
                </div>
            </div>
            <div class="card">
                <h3 style="color:var(--text3);font-size:10px;font-weight:700;letter-spacing:2px;margin-bottom:12px;">İSTATİSTİKLER</h3>
                <div class="info-table">
                    <div class="info-row"><span class="info-label">Toplam Sorgu</span><span class="info-value"><?=$user['total_queries']??0?></span></div>
                    <div class="info-row"><span class="info-label">Giriş Sayısı</span><span class="info-value"><?=$user['login_count']??0?></span></div>
                    <div class="info-row"><span class="info-label">Kayıt Tarihi</span><span class="info-value"><?=$user['created_at']?date('d.m.Y',strtotime($user['created_at'])):'—'?></span></div>
                    <div class="info-row"><span class="info-label">Son Giriş</span><span class="info-value"><?=$user['last_login']?date('d.m.Y H:i',strtotime($user['last_login'])):'—'?></span></div>
                </div>
            </div>
        </div>
    </main>
    <script src="/assets/js/main.js"></script>
</body>
</html>

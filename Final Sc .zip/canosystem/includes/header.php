<?php // Top bar ?>
<header class="topbar" id="topbar">
    <div class="topbar-left">
        <button class="topbar-toggle" id="sidebarToggle">☰</button>
        <span class="topbar-brand">CANO<span>SYSTEM</span></span>
    </div>
    <div class="topbar-right">
        <a href="/profile.php" class="topbar-avatar-emoji" title="Profil">👤</a>
        <a href="/logout.php" class="topbar-power" title="Güvenli Çıkış">⏻</a>
    </div>
</header>

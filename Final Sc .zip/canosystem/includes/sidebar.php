<?php
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$currentQuery = isset($_GET['type']) ? $_GET['type'] : '';
function sidebarActive($page,$current,$query='',$currentQ='') {
    if($query && $currentQ) return $query===$currentQ?'active':'';
    return $page===$current?'active':'';
}
$badgeClass = $_SESSION['user_type'] ?? 'free';
$badgeText = strtoupper($badgeClass);
if($badgeClass === 'free' && !empty($_SESSION['premium_until']) && strtotime($_SESSION['premium_until']) > time()) { $badgeClass='premium'; $badgeText='PREMIUM'; }
?>

<div class="sidebar-overlay" id="sidebarOverlay"></div>
<nav class="sidebar" id="sidebar">
    <!-- Profile Card -->
    <div class="sidebar-profile">
        <div class="sidebar-pp-emoji">👤<span class="online-dot"></span></div>
        <div class="sidebar-username">
            <?= sanitize($_SESSION['username'] ?? 'User') ?>
            <svg class="verified-tick" viewBox="0 0 22 22" width="16" height="16"><path d="M20.396 11c0-.795-.613-1.478-1.404-1.65-.23-1.19-.81-2.24-1.66-3.09-.51-.51-1.09-.92-1.73-1.2C15.3 4.08 14.66 3 13.7 3c-.74 0-1.39.37-1.7.94-.31-.57-.96-.94-1.7-.94-.96 0-1.6 1.08-1.9 2.06-.64.28-1.22.69-1.73 1.2-.85.85-1.43 1.9-1.66 3.09-.79.17-1.4.86-1.4 1.65 0 .8.63 1.49 1.42 1.65.24 1.18.82 2.23 1.66 3.07.51.51 1.09.92 1.73 1.2.3.98.94 2.06 1.9 2.06.74 0 1.39-.37 1.7-.94.31.57.96.94 1.7.94.96 0 1.6-1.08 1.9-2.06.64-.28 1.22-.69 1.73-1.2.84-.84 1.42-1.89 1.66-3.07.79-.16 1.42-.85 1.42-1.65z" fill="#1DA1F2"/><path d="M9.64 12.85l-2.05-2.05 1.06-1.06.99.99 3.15-3.15 1.06 1.06-4.21 4.21z" fill="#fff"/></svg>
        </div>
        <div class="sidebar-status">
            <span class="status-online">● Çevrimiçi</span>
            <span class="sidebar-badge <?= $badgeClass ?>"><?= $badgeText ?></span>
        </div>
    </div>

    <!-- Ana Menü -->
    <div class="sidebar-section">
        <div class="sidebar-section-title">ANA MENÜ</div>
        <a href="/dashboard.php" class="sidebar-item <?= sidebarActive('dashboard',$currentPage) ?>">
            <span class="si">🏠</span> Ana Sayfa
        </a>
    </div>

    <div class="sidebar-section">
        <div class="sidebar-section-title">MARKET</div>
        <a href="/market.php" class="sidebar-item <?= sidebarActive('market',$currentPage) ?>">
            <span class="si">🛒</span> Fiyat Listesi
        </a>
    </div>

    <!-- Ücretsiz Çözümler -->
    <div class="sidebar-section">
        <div class="sidebar-section-title">ÜCRETSIZ ÇÖZÜMLER</div>

        <div class="sidebar-cat" data-target="mernis_free">
            <div class="cat-left"><span class="si">🏛</span> Mernis Çözümleri</div>
            <span class="cat-toggle-icon">▼</span>
        </div>
        <div class="sidebar-children" id="mernis_free">
            <a href="/sorgu.php?type=tc" class="sidebar-child <?= sidebarActive('sorgu',$currentPage,'tc',$currentQuery) ?>"><span class="tag-free">FREE</span> TC Sorgu</a>
            <a href="/sorgu.php?type=adsoyad" class="sidebar-child <?= sidebarActive('sorgu',$currentPage,'adsoyad',$currentQuery) ?>"><span class="tag-free">FREE</span> Ad Soyad Sorgu</a>
            <a href="/sorgu.php?type=aile" class="sidebar-child <?= sidebarActive('sorgu',$currentPage,'aile',$currentQuery) ?>"><span class="tag-free">FREE</span> Aile Sorgusu</a>
            <a href="/sorgu.php?type=sulale" class="sidebar-child <?= sidebarActive('sorgu',$currentPage,'sulale',$currentQuery) ?>"><span class="tag-free">FREE</span> Şecere (Sulale)</a>
            <a href="/sorgu.php?type=es" class="sidebar-child <?= sidebarActive('sorgu',$currentPage,'es',$currentQuery) ?>"><span class="tag-free">FREE</span> Eş Sorgusu</a>
            <a href="/sorgu.php?type=cocuk" class="sidebar-child <?= sidebarActive('sorgu',$currentPage,'cocuk',$currentQuery) ?>"><span class="tag-free">FREE</span> Çocuk Sorgusu</a>
            <a href="/sorgu.php?type=anne" class="sidebar-child <?= sidebarActive('sorgu',$currentPage,'anne',$currentQuery) ?>"><span class="tag-free">FREE</span> Anne Sorgusu</a>
            <a href="/sorgu.php?type=baba" class="sidebar-child <?= sidebarActive('sorgu',$currentPage,'baba',$currentQuery) ?>"><span class="tag-free">FREE</span> Baba Sorgusu</a>
        </div>

        <div class="sidebar-cat" data-target="gsm_free">
            <div class="cat-left"><span class="si">📱</span> GSM Çözümleri</div>
            <span class="cat-toggle-icon">▼</span>
        </div>
        <div class="sidebar-children" id="gsm_free">
            <a href="/sorgu.php?type=gsmtc" class="sidebar-child <?= sidebarActive('sorgu',$currentPage,'gsmtc',$currentQuery) ?>"><span class="tag-free">FREE</span> GSM → TC</a>
            <a href="/sorgu.php?type=tcgsm" class="sidebar-child <?= sidebarActive('sorgu',$currentPage,'tcgsm',$currentQuery) ?>"><span class="tag-free">FREE</span> TC → GSM</a>
            <a href="/market.php" class="sidebar-child locked"><span class="tag-vip">VIP</span> GSM → TC 2026</a>
            <a href="/market.php" class="sidebar-child locked"><span class="tag-vip">VIP</span> TC → GSM 2026</a>
        </div>
    </div>

    <!-- Premium Çözümler -->
    <div class="sidebar-section">
        <div class="sidebar-section-title">PREMIUM ÇÖZÜMLER</div>
        <?php
        $premCats = [
            ['prem_mernis','🆔','Mernis 2026',['TC Sorgu','Ad Soyad Sorgu','Aile Sorgusu','Şecere (Sulale)','Eş Sorgusu','Çocuk Sorgusu','Anne Sorgusu','Baba Sorgusu'],'2026'],
            ['prem_maliye','💼','Maliye Çözümleri',['TC - İşyeri','TC - İşyeri Arkadaş','TC - İşyeri Müdür','TC - Maaş'],'VIP'],
            ['prem_adres','📍','Adres Çözümleri',['Adres Sorgu','Hane','TC - Vergi No','Vergi No - TC'],'VIP'],
            ['prem_arazi','🏔','Arazi Çözümleri',['TC - Tapu (2025)','Ada Parsel (2025)'],'VIP'],
            ['prem_iban','🏦','IBAN Çözümleri',['IBAN Sorgu V1','IBAN Sorgu V2'],'VIP'],
            ['prem_saglik','🩺','Sağlık Çözümleri',['Nöbetçi Eczane','Hastane Sorgu','Randevu Sorgu','Aşı Sorgu','Reçete Sorgu'],'VIP'],
            ['prem_kimlik','🪪','Kimlik Çözümleri',['Kimlik Oluşturucu','Hayat Hikaye Detay'],'VIP'],
            ['prem_askerlik','🎖','Askerlik Çözümleri',['Askerlik Sorgu'],'VIP'],
            ['prem_plaka','🚗','Plaka Çözümleri',['Plakadan TC','TC\'den Plaka','Plakadan GSM','GSM\'den Plaka'],'VIP'],
            ['prem_vesika','📷','Vesika Çözümleri',['E-Okul Vesika','Ehliyet Vesika'],'VIP'],
        ];
        foreach($premCats as $cat): ?>
        <div class="sidebar-cat" data-target="<?=$cat[0]?>">
            <div class="cat-left"><span class="si"><?=$cat[1]?></span> <?=$cat[2]?></div>
            <span class="cat-toggle-icon">▼</span>
        </div>
        <div class="sidebar-children" id="<?=$cat[0]?>">
            <?php foreach($cat[3] as $item): ?>
            <a href="/market.php" class="sidebar-child locked"><span class="tag-vip"><?=$cat[4]?></span> <?=$item?></a>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- VIP Özellikler -->
    <div class="sidebar-section">
        <div class="sidebar-section-title">VİP ÖZELLİKLER</div>
        <?php
        $vipCats = [
            ['vip_insta','📸','Instagram Çözümleri',['Gizli Profil Görüntüleme','Instagram Sızması','DM Mesaj Takibi','Gizli Hikaye İzleme','Şifresiz Takipçi Paneli']],
            ['vip_tiktok','🎵','TikTok Çözümleri',['Gizli Profil Görüntüleme','TikTok Sızması','DM Mesaj Takibi','Şifresiz Takipçi Paneli']],
            ['vip_edevlet','🏛','E-Devlet İşlemleri',['E-İmza Sorgu','E-Devlet Giriş','Kişiye Ait İmza','E-Devlet Vesika','Pasaport Bilgileri','QR Kodlu İkametgah','Adına Kayıtlı GSM','Enabiz Takip']],
            ['vip_telefon','📞','Telefon İşlemleri',['Telefon Sorgu','IMEI Sorgu','Anlık Konum Sorgu','Fatura Detay Döküm','Arama Kayıtları','İnternet Trafiği','Gizli Numara Sorgu']],
            ['vip_polnet','🚨','POLNET',['Scil Sorgu','Kom Arşiv Sorgu','Tem Arşiv Sorgu','Gözaltı Sorgu','Kişi Karıştığı Olaylar','Şahıs Adli İşlemleri','Adli Evrak Sorgu','Dava Sorgu','İcra Sorgu']],
            ['vip_wp','💬','WhatsApp Çözümleri',['WhatsApp Sızması','Silinen Mesajları Kurtar']],
            ['vip_gps','📡','Canlı Takip & GPS',['Numaradan Canlı Konum','Geçmiş Konum Hareketleri','Sinyal Kesici (Jammer)']],
            ['vip_medya','🖼','Medya & Galeri',['Galeri Sızması (Android)','Silinen Fotoğrafları Kurtar']],
            ['vip_seyahat','✈️','Konaklama & Seyahat',['Otel Konaklama Sorgu','Uçak/Otobüs Sorgu','Sınır Giriş-Çıkış Sorgu','Pasaport - Vize Sorgu']],
            ['vip_finans','💳','Finans & Banka',['Banka Hesap Bakiyesi','Kredi Kartı Hareketleri','Aktif POS Cihazı Sorgu']],
            ['vip_arsiv','🗄','Gelişmiş Arşiv',['Polis Telsiz Logları','Adli Sicil (Sabika) Sorgu']],
            ['vip_rat','🖥','Cihaz Kontrol (RAT)',['Mikrofon Dinleme','Dosya Yöneticisi Erişimi']],
        ];
        foreach($vipCats as $cat): ?>
        <div class="sidebar-cat" data-target="<?=$cat[0]?>">
            <div class="cat-left"><span class="si"><?=$cat[1]?></span> <?=$cat[2]?></div>
            <span class="cat-toggle-icon">▼</span>
        </div>
        <div class="sidebar-children" id="<?=$cat[0]?>">
            <?php foreach($cat[3] as $item): ?>
            <a href="/market.php" class="sidebar-child locked"><span class="tag-vip">VIP</span> <?=$item?></a>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Sistem -->
    <div class="sidebar-section" style="padding-bottom:24px;">
        <div class="sidebar-section-title">SİSTEM</div>
        <a href="/profile.php" class="sidebar-item <?= sidebarActive('profile',$currentPage) ?>">
            <span class="si">👤</span> Profil
        </a>
        <a href="/logout.php" class="sidebar-item sidebar-logout">
            <span class="si">⏻</span> Güvenli Çıkış
        </a>
    </div>
</nav>

#!/usr/bin/env python3
"""
CANO SYSTEM - Telegram Admin Bot
python-telegram-bot v20+ (async)
"""

import os
import sys
import json
import sqlite3
import hashlib
import bcrypt
import random
import string
import shutil
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes, ConversationHandler

# ===== CONFIG =====
BOT_TOKEN = "8799052923:AAGUFel08VUM4RF4IeRU9hMkXLFIM_UjWyk"
FOUNDER_ID = 8155730784
ADMIN_IDS = [8062233746, 8560239343]
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "db", "canosystem.db")
MAIL_DOMAIN = "@mocker.com"
PANEL_URL = "https://canopanel.site"

# Conversation states
WAITING_CUSTOM_ACCOUNT = 1
WAITING_SEARCH = 2
WAITING_PREMIUM_DURATION = 3
WAITING_MAIL_DOMAIN = 4
WAITING_PANEL_LINK = 5

# ===== DATABASE =====
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn

def hash_password(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def is_authorized(user_id):
    return user_id == FOUNDER_ID or user_id in ADMIN_IDS

def is_founder(user_id):
    return user_id == FOUNDER_ID

def get_mail_domain():
    try:
        conn = get_db()
        row = conn.execute("SELECT value FROM settings WHERE key = 'mail_domain'").fetchone()
        conn.close()
        return row['value'] if row else MAIL_DOMAIN
    except:
        return MAIL_DOMAIN

def get_panel_url():
    try:
        conn = get_db()
        row = conn.execute("SELECT value FROM settings WHERE key = 'panel_url'").fetchone()
        conn.close()
        return row['value'] if row else PANEL_URL
    except:
        return PANEL_URL

# ===== HANDLERS =====
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_authorized(user_id):
        await update.message.reply_text("⛔ Yetkiniz yok.")
        return

    keyboard = [
        [InlineKeyboardButton("🎁 Random Hesap", callback_data="random_account")],
        [InlineKeyboardButton("✨ Özel Hesap", callback_data="custom_account")],
        [InlineKeyboardButton("👥 Tüm Hesaplar", callback_data="all_accounts")],
        [InlineKeyboardButton("🔍 Hesap Ara", callback_data="search_account")],
        [InlineKeyboardButton("📊 İstatistikler", callback_data="stats")],
        [InlineKeyboardButton("💾 Yedekle", callback_data="backup")],
    ]

    if is_founder(user_id):
        keyboard.append([InlineKeyboardButton("👑 Kurucu Paneli", callback_data="founder_panel")])

    panel_url = get_panel_url()
    text = (
        f"🟢 <b>CANO SYSTEM Admin Panel</b>\n\n"
        f"🌐 Panel: {panel_url}\n"
        f"📌 Bir işlem seçin:"
    )
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

# Random Account
async def random_account(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    rand = random.randint(1000, 99999)
    username = f"user{rand}"
    domain = get_mail_domain()
    email = f"{username}{domain}"
    password = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    hashed = hash_password(password)

    try:
        conn = get_db()
        conn.execute(
            "INSERT INTO users (username, email, password, user_type, status) VALUES (?, ?, ?, 'free', 'active')",
            (username, email, hashed)
        )
        conn.commit()
        user_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.close()

        keyboard = [
            [InlineKeyboardButton("⭐ Premium Ver", callback_data=f"give_premium_{user_id}")],
            [InlineKeyboardButton("🗑️ Sil", callback_data=f"delete_user_{user_id}")],
            [InlineKeyboardButton("🔙 Ana Menü", callback_data="main_menu")],
        ]

        text = (
            f"✅ <b>Hesap Oluşturuldu!</b>\n\n"
            f"👤 Kullanıcı: <code>{username}</code>\n"
            f"📧 Email: <code>{email}</code>\n"
            f"🔑 Şifre: <code>{password}</code>\n"
            f"📌 Durum: FREE"
        )
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
    except Exception as e:
        await query.edit_message_text(f"❌ Hata: {str(e)}")

# Custom Account - Ask for input
async def custom_account_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        "✨ <b>Özel Hesap Oluştur</b>\n\n"
        "Format: <code>kullaniciadi email sifre</code>\n\n"
        "Örnek: <code>ahmet ahmet@mocker.com sifre123</code>\n\n"
        "Yazın veya /iptal ile çıkın:",
        parse_mode="HTML"
    )
    return WAITING_CUSTOM_ACCOUNT

async def custom_account_create(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    parts = text.split()

    if len(parts) < 3:
        await update.message.reply_text("❌ Format hatalı. Kullanım: <code>username email şifre</code>", parse_mode="HTML")
        return WAITING_CUSTOM_ACCOUNT

    username, email, password = parts[0], parts[1], parts[2]
    hashed = hash_password(password)

    try:
        conn = get_db()
        conn.execute(
            "INSERT INTO users (username, email, password, user_type, status) VALUES (?, ?, ?, 'free', 'active')",
            (username, email, hashed)
        )
        conn.commit()
        user_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.close()

        keyboard = [
            [InlineKeyboardButton("⭐ Premium Ver", callback_data=f"give_premium_{user_id}")],
            [InlineKeyboardButton("🗑️ Sil", callback_data=f"delete_user_{user_id}")],
            [InlineKeyboardButton("🔙 Ana Menü", callback_data="main_menu")],
        ]

        await update.message.reply_text(
            f"✅ <b>Hesap Oluşturuldu!</b>\n\n"
            f"👤 Kullanıcı: <code>{username}</code>\n"
            f"📧 Email: <code>{email}</code>\n"
            f"🔑 Şifre: <code>{password}</code>\n"
            f"📌 Durum: FREE",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except sqlite3.IntegrityError:
        await update.message.reply_text("❌ Bu kullanıcı adı veya email zaten mevcut.")
        return WAITING_CUSTOM_ACCOUNT
    except Exception as e:
        await update.message.reply_text(f"❌ Hata: {str(e)}")

    return ConversationHandler.END

# All Accounts
async def all_accounts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    conn = get_db()
    users = conn.execute("SELECT id, username, email, user_type, status FROM users ORDER BY id DESC LIMIT 10").fetchall()
    conn.close()

    if not users:
        await query.edit_message_text("📭 Henüz hesap yok.")
        return

    text = "👥 <b>Son 10 Hesap</b>\n\n"
    for u in users:
        status_icon = "🟢" if u['status'] == 'active' else "🔴"
        type_icon = "👑" if u['user_type'] == 'admin' else "⭐" if u['user_type'] == 'premium' else "🆓"
        text += f"{status_icon} {type_icon} <b>{u['username']}</b> — {u['email']}\n"

    keyboard = [[InlineKeyboardButton("🔙 Ana Menü", callback_data="main_menu")]]
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

# Search Account
async def search_account_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await query.edit_message_text("🔍 <b>Hesap Ara</b>\n\nKullanıcı adı veya email yazın:", parse_mode="HTML")
    return WAITING_SEARCH

async def search_account_do(update: Update, context: ContextTypes.DEFAULT_TYPE):
    term = update.message.text.strip()
    conn = get_db()
    users = conn.execute(
        "SELECT * FROM users WHERE username LIKE ? OR email LIKE ? LIMIT 5",
        (f"%{term}%", f"%{term}%")
    ).fetchall()
    conn.close()

    if not users:
        await update.message.reply_text("❌ Sonuç bulunamadı.")
        return ConversationHandler.END

    for u in users:
        premium_text = "—"
        if u['premium_until']:
            premium_text = u['premium_until']

        keyboard = [
            [InlineKeyboardButton("⭐ Premium Ver", callback_data=f"give_premium_{u['id']}")],
            [InlineKeyboardButton("🗑️ Sil", callback_data=f"delete_user_{u['id']}")],
        ]

        text = (
            f"👤 <b>{u['username']}</b>\n"
            f"📧 {u['email']}\n"
            f"📌 Tip: {u['user_type'].upper()}\n"
            f"⏰ Premium: {premium_text}\n"
            f"🔢 Sorgular: {u['total_queries']}\n"
            f"🔐 Durum: {u['status'].upper()}"
        )
        await update.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

    return ConversationHandler.END

# Stats
async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    conn = get_db()
    total = conn.execute("SELECT COUNT(*) as c FROM users").fetchone()['c']
    premium = conn.execute("SELECT COUNT(*) as c FROM users WHERE user_type = 'premium' OR (premium_until IS NOT NULL AND premium_until > datetime('now','localtime'))").fetchone()['c']
    admins = conn.execute("SELECT COUNT(*) as c FROM users WHERE user_type = 'admin'").fetchone()['c']
    total_logins = conn.execute("SELECT COUNT(*) as c FROM login_logs").fetchone()['c']
    total_queries = conn.execute("SELECT COUNT(*) as c FROM query_logs").fetchone()['c']
    conn.close()

    text = (
        f"📊 <b>CANO SYSTEM İstatistikleri</b>\n\n"
        f"👥 Toplam Hesap: <b>{total}</b>\n"
        f"👑 Admin: <b>{admins}</b>\n"
        f"⭐ Premium: <b>{premium}</b>\n"
        f"🆓 Free: <b>{total - premium - admins}</b>\n\n"
        f"🔑 Toplam Giriş: <b>{total_logins}</b>\n"
        f"🔍 Toplam Sorgu: <b>{total_queries}</b>"
    )

    keyboard = [[InlineKeyboardButton("🔙 Ana Menü", callback_data="main_menu")]]
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

# Backup
async def backup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if not os.path.exists(DB_PATH):
        await query.edit_message_text("❌ Database bulunamadı.")
        return

    backup_path = DB_PATH + f".backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    shutil.copy2(DB_PATH, backup_path)

    await query.edit_message_text("⏳ Yedek hazırlanıyor...")
    await context.bot.send_document(
        chat_id=update.effective_chat.id,
        document=open(backup_path, 'rb'),
        filename=f"canosystem_backup_{datetime.now().strftime('%Y%m%d')}.db",
        caption="💾 Database yedeği başarıyla oluşturuldu!"
    )

    # Clean up backup file
    try:
        os.remove(backup_path)
    except:
        pass

# Give Premium
async def give_premium_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    data = query.data  # give_premium_123
    user_id = int(data.split("_")[-1])
    context.user_data['premium_user_id'] = user_id

    keyboard = [
        [InlineKeyboardButton("2 Gün", callback_data="prem_2d"),
         InlineKeyboardButton("7 Gün", callback_data="prem_7d")],
        [InlineKeyboardButton("1 Ay", callback_data="prem_1m"),
         InlineKeyboardButton("3 Ay", callback_data="prem_3m")],
        [InlineKeyboardButton("1 Yıl", callback_data="prem_1y"),
         InlineKeyboardButton("Sınırsız", callback_data="prem_unlimited")],
        [InlineKeyboardButton("🔙 Ana Menü", callback_data="main_menu")],
    ]

    await query.edit_message_text(
        f"⭐ <b>Premium Süresi Seçin</b>\n\nHesap ID: {user_id}",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def give_premium_set(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = context.user_data.get('premium_user_id')
    if not user_id:
        await query.edit_message_text("❌ Hata: Kullanıcı seçilmemiş.")
        return

    choice = query.data  # prem_2d, prem_1m, etc.
    now = datetime.now()

    if choice == "prem_2d":
        until = now + timedelta(days=2)
        label = "2 Gün"
    elif choice == "prem_7d":
        until = now + timedelta(days=7)
        label = "7 Gün"
    elif choice == "prem_1m":
        until = now + timedelta(days=30)
        label = "1 Ay"
    elif choice == "prem_3m":
        until = now + timedelta(days=90)
        label = "3 Ay"
    elif choice == "prem_1y":
        until = now + timedelta(days=365)
        label = "1 Yıl"
    elif choice == "prem_unlimited":
        until = now + timedelta(days=36500)  # ~100 years
        label = "Sınırsız"
    else:
        return

    try:
        conn = get_db()
        conn.execute(
            "UPDATE users SET user_type = 'premium', premium_until = ? WHERE id = ?",
            (until.strftime('%Y-%m-%d %H:%M:%S'), user_id)
        )
        conn.commit()
        user = conn.execute("SELECT username, email FROM users WHERE id = ?", (user_id,)).fetchone()
        conn.close()

        keyboard = [[InlineKeyboardButton("🔙 Ana Menü", callback_data="main_menu")]]
        await query.edit_message_text(
            f"✅ <b>Premium Verildi!</b>\n\n"
            f"👤 {user['username']} ({user['email']})\n"
            f"⏰ Süre: {label}\n"
            f"📅 Bitiş: {until.strftime('%d.%m.%Y %H:%M')}",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        await query.edit_message_text(f"❌ Hata: {str(e)}")

# Delete User
async def delete_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = int(query.data.split("_")[-1])

    keyboard = [
        [InlineKeyboardButton("✅ Evet, Sil", callback_data=f"confirm_delete_{user_id}"),
         InlineKeyboardButton("❌ İptal", callback_data="main_menu")],
    ]
    await query.edit_message_text(f"⚠️ Hesap #{user_id} silinecek. Emin misiniz?", reply_markup=InlineKeyboardMarkup(keyboard))

async def confirm_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = int(query.data.split("_")[-1])

    try:
        conn = get_db()
        conn.execute("DELETE FROM query_logs WHERE user_id = ?", (user_id,))
        conn.execute("DELETE FROM login_logs WHERE user_id = ?", (user_id,))
        conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.commit()
        conn.close()

        keyboard = [[InlineKeyboardButton("🔙 Ana Menü", callback_data="main_menu")]]
        await query.edit_message_text(f"🗑️ Hesap #{user_id} silindi.", reply_markup=InlineKeyboardMarkup(keyboard))
    except Exception as e:
        await query.edit_message_text(f"❌ Hata: {str(e)}")

# Founder Panel
async def founder_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if not is_founder(query.from_user.id):
        await query.edit_message_text("⛔ Sadece kurucu erişebilir.")
        return

    domain = get_mail_domain()
    panel = get_panel_url()

    keyboard = [
        [InlineKeyboardButton(f"📧 Mail Domain: {domain}", callback_data="change_domain")],
        [InlineKeyboardButton(f"🔗 Panel: {panel}", callback_data="change_panel")],
        [InlineKeyboardButton("🔙 Ana Menü", callback_data="main_menu")],
    ]

    await query.edit_message_text("👑 <b>Kurucu Paneli</b>", parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

# Change Domain
async def change_domain_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_founder(query.from_user.id):
        return

    await query.edit_message_text(
        f"📧 <b>Mail Domain Değiştir</b>\n\nMevcut: {get_mail_domain()}\n\nYeni domain yazın (ör: @mocker.in):",
        parse_mode="HTML"
    )
    return WAITING_MAIL_DOMAIN

async def change_domain_do(update: Update, context: ContextTypes.DEFAULT_TYPE):
    new_domain = update.message.text.strip()
    if not new_domain.startswith('@'):
        new_domain = '@' + new_domain

    conn = get_db()
    conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('mail_domain', ?)", (new_domain,))
    conn.commit()
    conn.close()

    await update.message.reply_text(f"✅ Mail domain değiştirildi: <b>{new_domain}</b>", parse_mode="HTML")
    return ConversationHandler.END

# Change Panel Link
async def change_panel_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_founder(query.from_user.id):
        return

    await query.edit_message_text(
        f"🔗 <b>Panel Link Değiştir</b>\n\nMevcut: {get_panel_url()}\n\nYeni link yazın:",
        parse_mode="HTML"
    )
    return WAITING_PANEL_LINK

async def change_panel_do(update: Update, context: ContextTypes.DEFAULT_TYPE):
    new_url = update.message.text.strip()
    conn = get_db()
    conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('panel_url', ?)", (new_url,))
    conn.commit()
    conn.close()

    await update.message.reply_text(f"✅ Panel link değiştirildi: <b>{new_url}</b>", parse_mode="HTML")
    return ConversationHandler.END

# Main Menu callback
async def main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    keyboard = [
        [InlineKeyboardButton("🎁 Random Hesap", callback_data="random_account")],
        [InlineKeyboardButton("✨ Özel Hesap", callback_data="custom_account")],
        [InlineKeyboardButton("👥 Tüm Hesaplar", callback_data="all_accounts")],
        [InlineKeyboardButton("🔍 Hesap Ara", callback_data="search_account")],
        [InlineKeyboardButton("📊 İstatistikler", callback_data="stats")],
        [InlineKeyboardButton("💾 Yedekle", callback_data="backup")],
    ]
    if is_founder(user_id):
        keyboard.append([InlineKeyboardButton("👑 Kurucu Paneli", callback_data="founder_panel")])

    panel_url = get_panel_url()
    await query.edit_message_text(
        f"🟢 <b>CANO SYSTEM Admin Panel</b>\n\n🌐 Panel: {panel_url}\n📌 Bir işlem seçin:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# Cancel
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("İptal edildi. /start ile yeniden başlayın.")
    return ConversationHandler.END

# ===== MAIN =====
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    # Conversation: Custom Account
    custom_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(custom_account_start, pattern="^custom_account$")],
        states={WAITING_CUSTOM_ACCOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, custom_account_create)]},
        fallbacks=[CommandHandler("iptal", cancel)],
    )

    # Conversation: Search
    search_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(search_account_start, pattern="^search_account$")],
        states={WAITING_SEARCH: [MessageHandler(filters.TEXT & ~filters.COMMAND, search_account_do)]},
        fallbacks=[CommandHandler("iptal", cancel)],
    )

    # Conversation: Change Domain
    domain_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(change_domain_start, pattern="^change_domain$")],
        states={WAITING_MAIL_DOMAIN: [MessageHandler(filters.TEXT & ~filters.COMMAND, change_domain_do)]},
        fallbacks=[CommandHandler("iptal", cancel)],
    )

    # Conversation: Change Panel
    panel_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(change_panel_start, pattern="^change_panel$")],
        states={WAITING_PANEL_LINK: [MessageHandler(filters.TEXT & ~filters.COMMAND, change_panel_do)]},
        fallbacks=[CommandHandler("iptal", cancel)],
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(custom_conv)
    app.add_handler(search_conv)
    app.add_handler(domain_conv)
    app.add_handler(panel_conv)

    app.add_handler(CallbackQueryHandler(random_account, pattern="^random_account$"))
    app.add_handler(CallbackQueryHandler(all_accounts, pattern="^all_accounts$"))
    app.add_handler(CallbackQueryHandler(stats, pattern="^stats$"))
    app.add_handler(CallbackQueryHandler(backup, pattern="^backup$"))
    app.add_handler(CallbackQueryHandler(founder_panel, pattern="^founder_panel$"))
    app.add_handler(CallbackQueryHandler(main_menu, pattern="^main_menu$"))
    app.add_handler(CallbackQueryHandler(give_premium_start, pattern=r"^give_premium_\d+$"))
    app.add_handler(CallbackQueryHandler(give_premium_set, pattern=r"^prem_"))
    app.add_handler(CallbackQueryHandler(delete_user, pattern=r"^delete_user_\d+$"))
    app.add_handler(CallbackQueryHandler(confirm_delete, pattern=r"^confirm_delete_\d+$"))

    print("🤖 CANO SYSTEM Bot başlatıldı!")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()

<?php
// CANO SYSTEM - Database Initializer
require_once __DIR__ . '/config/database.php';

try {
    $db = getDB();
    
    // Users table
    $db->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        user_type TEXT DEFAULT 'free' CHECK(user_type IN ('admin','free','premium')),
        status TEXT DEFAULT 'active' CHECK(status IN ('active','banned','suspended')),
        created_at DATETIME DEFAULT (datetime('now','localtime')),
        premium_until DATETIME NULL,
        last_login DATETIME NULL,
        ip_address TEXT NULL,
        device_info TEXT NULL,
        total_queries INTEGER DEFAULT 0,
        login_count INTEGER DEFAULT 0
    )");

    // Login logs
    $db->exec("CREATE TABLE IF NOT EXISTS login_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        ip_address TEXT,
        user_agent TEXT,
        login_time DATETIME DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");

    // Query logs
    $db->exec("CREATE TABLE IF NOT EXISTS query_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        query_type TEXT NOT NULL,
        query_data TEXT,
        ip_address TEXT,
        query_time DATETIME DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");

    // Settings table
    $db->exec("CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )");

    // Default settings
    $defaults = [
        'mail_domain' => '@mocker.com',
        'panel_url' => 'https://canopanel.site',
        'telegram_channel' => '@canodestekhat',
    ];
    $stmtS = $db->prepare("INSERT OR IGNORE INTO settings (key, value) VALUES (:key, :value)");
    foreach ($defaults as $k => $v) {
        $stmtS->execute([':key' => $k, ':value' => $v]);
    }

    // Create admin account
    $adminEmail = 'admin@mocker.com';
    $adminPass = password_hash('admin123', PASSWORD_BCRYPT);
    
    $check = $db->prepare("SELECT id FROM users WHERE email = :email");
    $check->execute([':email' => $adminEmail]);
    
    if (!$check->fetch()) {
        $stmt = $db->prepare("INSERT INTO users (username, email, password, user_type, status) VALUES (:username, :email, :password, 'admin', 'active')");
        $stmt->execute([
            ':username' => 'Admin',
            ':email' => $adminEmail,
            ':password' => $adminPass
        ]);
        echo "✅ Admin hesabı oluşturuldu: admin@mocker.com / admin123\n";
    } else {
        echo "ℹ️ Admin hesabı zaten mevcut.\n";
    }

    echo "✅ Database başarıyla oluşturuldu!\n";
    echo "📁 Konum: " . DB_PATH . "\n";
    
} catch (Exception $e) {
    echo "❌ Hata: " . $e->getMessage() . "\n";
}

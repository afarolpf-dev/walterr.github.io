# CANO SYSTEM v2.0

## 🚀 Kurulum

### 1. Dosyaları VDS'e Yükle
```bash
# ZIP'i VDS'e yükle ve aç
unzip canosystem.zip -d /var/www/html/canosystem
# veya XAMPP kullanıyorsan:
unzip canosystem.zip -d C:/xampp/htdocs/canosystem
```

### 2. Database Oluştur
```bash
cd /var/www/html/canosystem
php init.php
```
Bu komut:
- SQLite database oluşturur (`db/canosystem.db`)
- Admin hesabı ekler: `admin@mocker.com` / `admin123`

### 3. Config Ayarları
`config/database.php` dosyasını düzenle:
```php
define('TELEGRAM_BOT_TOKEN', 'BOTFATHER_TOKEN');
define('FOUNDER_ID', 123456789);  // Telegram ID'n
define('API_KEY', 'MOCKERAPI_KEY');
```

### 4. Apache VirtualHost
```apache
<VirtualHost *:80>
    ServerName canopanel.site
    DocumentRoot /var/www/html/canosystem
    
    <Directory /var/www/html/canosystem>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

### 5. Telegram Bot
```bash
cd /var/www/html/canosystem
pip install -r requirements.txt
```

`bot.py` dosyasını düzenle:
```python
BOT_TOKEN = "BOTFATHER_TOKEN"
FOUNDER_ID = 123456789  # Telegram ID'n
ADMIN_IDS = []  # Diğer admin ID'leri
```

Botu başlat:
```bash
python3 bot.py
# veya arka planda:
nohup python3 bot.py &
# veya screen ile:
screen -S canobot python3 bot.py
```

### 6. Cloudflare DNS
- A Record: `canopanel.site` → VDS IP
- Proxy: ON (turuncu bulut)
- SSL: Full (Strict)

## 📂 Dosya Yapısı
```
canosystem/
├── config/
│   └── database.php      # DB bağlantı + ayarlar
├── db/
│   └── canosystem.db     # SQLite (init.php ile oluşur)
├── includes/
│   ├── sidebar.php        # Sidebar menü
│   └── header.php         # Top bar
├── assets/
│   ├── css/style.css      # Ana stil dosyası
│   └── js/main.js         # JavaScript
├── api/
│   └── query.php          # API proxy (frontend → mockerapi.shop)
├── .htaccess              # Güvenlik kuralları
├── index.php              # Login sayfası
├── dashboard.php          # Ana sayfa
├── sorgu.php              # Sorgu sayfası
├── market.php             # Fiyatlar
├── profile.php            # Profil
├── logout.php             # Çıkış
├── init.php               # Database kurulum
├── bot.py                 # Telegram admin bot
├── requirements.txt       # Python gereksinimleri
└── README.md              # Bu dosya
```

## 🔐 Güvenlik
- SQL Injection: Prepared Statements
- XSS: htmlspecialchars() ile sanitize
- CSRF: Token validation her formda
- Session: httponly, samesite=Strict
- .htaccess: config/, db/, includes/ klasörleri kapalı
- .db, .env, .sqlite dosyaları bloke
- Cloudflare ile IP gizleme
- API key sunucu tarafında, frontend'e sızmaz
- Security headers: X-Frame-Options, X-Content-Type-Options, vb.

## 🤖 Bot Komutları
- `/start` - Ana menü
- `🎁 Random Hesap` - Rastgele hesap oluştur
- `✨ Özel Hesap` - Manuel hesap oluştur
- `👥 Tüm Hesaplar` - Son 10 hesap listele
- `🔍 Hesap Ara` - Email/username ile ara
- `📊 İstatistikler` - Toplam hesap, sorgu, giriş
- `💾 Yedekle` - Database yedeğini indir
- `👑 Kurucu Paneli` - Domain/link değiştir (sadece kurucu)

## ⚠️ Önemli
- İlk girişte `php init.php` çalıştırmayı unutma
- Bot token'ı hem `config/database.php` hem `bot.py`'da güncelle
- Production'da HTTPS zorunlu: `.htaccess`'te HTTPS rewrite'ı aç
- `init.php`'ye tarayıcıdan erişim .htaccess ile engellenmiş

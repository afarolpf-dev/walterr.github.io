<?php
require_once __DIR__ . '/config/database.php';
initSession();
if (isset($_SESSION['user_id'])) { header('Location: /dashboard.php'); exit; }
$error = '';
if (!isset($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['csrf_token'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($csrf, $token)) { $error = 'Güvenlik hatası.'; }
    else {
        $action = $_POST['action'] ?? 'login';
        $db = getDB();
        if ($action === 'login') {
            $email = trim($_POST['email'] ?? ''); $password = $_POST['password'] ?? '';
            if (empty($email) || empty($password)) { $error = 'Tüm alanları doldurun.'; }
            else {
                $stmt = $db->prepare("SELECT * FROM users WHERE email=:email OR username=:email LIMIT 1");
                $stmt->execute([':email' => $email]); $user = $stmt->fetch();
                if ($user && password_verify($password, $user['password'])) {
                    if ($user['status'] !== 'active') { $error = 'Hesap askıda.'; }
                    else {
                        $_SESSION['user_id']=$user['id'];$_SESSION['username']=$user['username'];
                        $_SESSION['email']=$user['email'];$_SESSION['user_type']=$user['user_type'];
                        $_SESSION['premium_until']=$user['premium_until'];
                        $ip=getClientIP();$ua=$_SERVER['HTTP_USER_AGENT']??'';
                        $db->prepare("UPDATE users SET last_login=datetime('now','localtime'),login_count=login_count+1,ip_address=:ip,device_info=:ua WHERE id=:id")->execute([':ip'=>$ip,':ua'=>$ua,':id'=>$user['id']]);
                        $db->prepare("INSERT INTO login_logs(user_id,ip_address,user_agent)VALUES(:uid,:ip,:ua)")->execute([':uid'=>$user['id'],':ip'=>$ip,':ua'=>$ua]);
                        session_regenerate_id(true);unset($_SESSION['tg_popup_shown']);header('Location: /dashboard.php');exit;
                    }
                } else { $error = 'Email veya şifre hatalı.'; }
            }
        } elseif ($action === 'canofree') {
            $username='CanoFree';
            $domainStmt=$db->prepare("SELECT value FROM settings WHERE key='mail_domain'");$domainStmt->execute();
            $domainRow=$domainStmt->fetch();$domain=$domainRow?$domainRow['value']:'@mocker.com';
            $email='canofree'.mt_rand(100,999).$domain;$password=bin2hex(random_bytes(4));
            $hashed=password_hash($password,PASSWORD_BCRYPT);$ip=getClientIP();
            $check=$db->prepare("SELECT * FROM users WHERE username='CanoFree' AND user_type='free' LIMIT 1");
            $check->execute();$existing=$check->fetch();
            if($existing){$userId=$existing['id'];}
            else{try{$stmt=$db->prepare("INSERT INTO users(username,email,password,user_type,status,ip_address)VALUES(:u,:e,:p,'free','active',:ip)");
            $stmt->execute([':u'=>$username,':e'=>$email,':p'=>$hashed,':ip'=>$ip]);$userId=$db->lastInsertId();}catch(Exception $e){$error='Hata.';$userId=null;}}
            if($userId){$u=$db->prepare("SELECT * FROM users WHERE id=:id");$u->execute([':id'=>$userId]);$user=$u->fetch();
            $_SESSION['user_id']=$user['id'];$_SESSION['username']=$user['username'];$_SESSION['email']=$user['email'];
            $_SESSION['user_type']=$user['user_type'];$_SESSION['premium_until']=$user['premium_until'];
            $db->prepare("UPDATE users SET last_login=datetime('now','localtime'),login_count=login_count+1 WHERE id=:id")->execute([':id'=>$userId]);
            session_regenerate_id(true);unset($_SESSION['tg_popup_shown']);header('Location: /dashboard.php');exit;}
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>CANO SYSTEM - Bedava Sorgu Paneli 2026 | Türkiye'nin En İyi Ücretsiz Sorgu Paneli</title>
    <meta name="description" content="CANO SYSTEM - Bedava Sorgu Paneli 2026. Türkiye'nin en gelişmiş ücretsiz sorgu paneli.">
    <meta name="keywords" content="sorgu paneli, bedava sorgu paneli, ücretsiz sorgu paneli 2026, tc sorgu, mernis sorgu, gsm sorgu, cano system">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="CANO SYSTEM - Bedava Sorgu Paneli 2026">
    <meta property="og:description" content="Türkiye'nin en gelişmiş ücretsiz sorgu paneli. TC, Ad Soyad, Aile, GSM sorguları.">
    <meta property="og:type" content="website"><meta property="og:url" content="https://canopanel.site">
    <link rel="icon" href="/assets/logo.jpg" type="image/jpeg">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="page-loader" id="pageLoader"><div style="text-align:center;"><div class="loader-spinner"></div><div class="loader-text">CANO SYSTEM</div></div></div>

    <div class="login-container">
        <div class="login-bg-1"></div>
        <div class="login-bg-2"></div>

        <div class="login-box">
            <div class="login-logo">
                <h1>CANO<span>SYSTEM</span></h1>
                <p>Sorgu & Yönetim Paneli</p>
            </div>
            <div class="login-card">
                <?php if($error):?><div class="alert alert-error"><?=sanitize($error)?></div><?php endif;?>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?=$csrf?>">
                    <input type="hidden" name="action" value="login">
                    <div class="form-group"><input type="text" name="email" class="form-input" placeholder="Email veya Kullanıcı Adı" autocomplete="username" required></div>
                    <div class="form-group"><input type="password" name="password" class="form-input" placeholder="Şifre" autocomplete="current-password" required></div>
                    <button type="submit" class="btn btn-primary">GİRİŞ YAP</button>
                </form>
                <div class="divider"><span>veya</span></div>
                <button class="btn btn-secondary" onclick="openModal('freeModal')">🎁 ÜCRETSİZ GİRİŞ (CANOFREE)</button>
            </div>
            <div class="login-footer">CANO SYSTEM v2.0 — Powered by <span>Mocker</span></div>
        </div>
    </div>

    <div class="modal-overlay" id="freeModal">
        <div class="modal">
            <button class="tg-popup-close" onclick="closeModal('freeModal')">✕</button>
            <div style="font-size:36px;margin-bottom:6px;">🎁</div>
            <h3>CanoFree Hesap</h3>
            <p>Ücretsiz demo hesabıyla panele giriş yapılacak.</p>
            <div class="modal-actions">
                <button class="btn btn-secondary btn-sm" onclick="closeModal('freeModal')">İptal</button>
                <form method="POST" style="flex:1;"><input type="hidden" name="csrf_token" value="<?=$csrf?>"><input type="hidden" name="action" value="canofree">
                <button type="submit" class="btn btn-primary btn-sm btn-block">Devam Et</button></form>
            </div>
        </div>
    </div>
    <script src="/assets/js/main.js"></script>
</body>
</html>

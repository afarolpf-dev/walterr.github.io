document.addEventListener('DOMContentLoaded',function(){
var loader=document.getElementById('pageLoader');
if(loader)setTimeout(function(){loader.classList.add('hidden');},500);

var sidebar=document.getElementById('sidebar'),overlay=document.getElementById('sidebarOverlay'),topbar=document.getElementById('topbar'),main=document.getElementById('mainContent'),tog=document.getElementById('sidebarToggle');
if(tog)tog.addEventListener('click',function(){
if(window.innerWidth<768){sidebar.classList.toggle('open');overlay.classList.toggle('active');}
else{sidebar.classList.toggle('closed');topbar.classList.toggle('collapsed');main.classList.toggle('full');}
});
if(overlay)overlay.addEventListener('click',function(){sidebar.classList.remove('open');overlay.classList.remove('active');});

var cats=document.querySelectorAll('.sidebar-cat');
for(var i=0;i<cats.length;i++){cats[i].addEventListener('click',function(e){
e.preventDefault();var t=this.getAttribute('data-target'),ch=document.getElementById(t),ic=this.querySelector('.cat-toggle-icon');
if(!ch)return;
if(ch.classList.contains('open')){ch.classList.remove('open');this.classList.remove('open');if(ic)ic.textContent='▼';}
else{ch.classList.add('open');this.classList.add('open');if(ic)ic.textContent='▲';}
});}

var links=document.querySelectorAll('.sidebar-item,.sidebar-child');
for(var j=0;j<links.length;j++){links[j].addEventListener('click',function(){
if(window.innerWidth<768&&sidebar){sidebar.classList.remove('open');if(overlay)overlay.classList.remove('active');}
});}

var faqs=document.querySelectorAll('.faq-question');
for(var k=0;k<faqs.length;k++){faqs[k].addEventListener('click',function(){
var item=this.closest('.faq-item'),tg=this.querySelector('.faq-toggle');
item.classList.toggle('open');if(tg)tg.textContent=item.classList.contains('open')?'−':'+';
});}
});

function doQuery(f,r){
var form=document.getElementById(f),res=document.getElementById(r);if(!form||!res)return;
var fd=new FormData(form),btn=form.querySelector('button[type="submit"]'),bt=btn.innerHTML;
btn.disabled=true;btn.innerHTML='<span class="btn-loader"></span> Sorgulanıyor...';
res.innerHTML='<div class="inline-loader"><div class="mini-spinner"></div><span style="font-family:Space Mono,monospace;font-size:11px;letter-spacing:1px;">Sorgulanıyor...</span></div>';
var x=new XMLHttpRequest();x.open('POST',form.action,true);
x.onreadystatechange=function(){if(x.readyState!==4)return;
setTimeout(function(){btn.disabled=false;btn.innerHTML=bt;
if(x.status!==200){res.innerHTML='<div class="error-msg">❌ Bağlantı hatası</div>';return;}
try{var d=JSON.parse(x.responseText);}catch(e){res.innerHTML='<div class="error-msg">❌ Yanıt hatası</div>';return;}
if(d.status===false||d.error){res.innerHTML='<div class="error-msg">❌ '+esc(d.mesaj||d.error||'Sonuç bulunamadı')+'</div>';return;}
var s=d.sonuc,fmt=d.format||'single';
if(!s||(Array.isArray(s)&&s.length===0)||(typeof s==='object'&&Object.keys(s).length===0)){res.innerHTML='<div class="no-result">Sonuç bulunamadı</div>';return;}
var h='<div class="export-btns"><button class="btn btn-sm btn-secondary" onclick="exportCSV()">📄 CSV</button><button class="btn btn-sm btn-secondary" onclick="exportExcel()">📊 Excel</button></div>';
if(fmt==='table'&&Array.isArray(s)&&s.length>0){var ak=[],sk=['ortak_cocuklar','UYRUK'];
for(var r2=0;r2<s.length;r2++){var rk=Object.keys(s[r2]);for(var x2=0;x2<rk.length;x2++){if(ak.indexOf(rk[x2])===-1)ak.push(rk[x2]);}}
var dk=[];for(var d2=0;d2<ak.length;d2++){if(sk.indexOf(ak[d2])===-1)dk.push(ak[d2]);}
h+='<table id="resultTable"><thead><tr>';for(var hh=0;hh<dk.length;hh++)h+='<th>'+esc(dk[hh])+'</th>';
h+='</tr></thead><tbody>';for(var t=0;t<s.length;t++){h+='<tr>';for(var c=0;c<dk.length;c++){var v=s[t][dk[c]];if(v===undefined||v===null)v='';if(Array.isArray(v))v=v.join(', ');h+='<td>'+esc(String(v))+'</td>';}h+='</tr>';}h+='</tbody></table>';
}else{h+='<table id="resultTable"><tbody>';var en=Object.entries(s);
for(var e=0;e<en.length;e++){var key=en[e][0],val=en[e][1];if(key==='UYRUK'&&(!val||val===''))continue;if(key==='ortak_cocuklar')continue;if(Array.isArray(val))val=val.join(', ');h+='<tr><td class="result-key">'+esc(key)+'</td><td class="result-val">'+esc(String(val||''))+'</td></tr>';}
h+='</tbody></table>';}res.innerHTML=h;},2000);};x.send(fd);}

function exportCSV(){var t=document.getElementById('resultTable');if(!t)return;var c=[],rows=t.querySelectorAll('tr');for(var i=0;i<rows.length;i++){var r=[],cells=rows[i].querySelectorAll('th,td');for(var j=0;j<cells.length;j++)r.push('"'+cells[j].textContent.replace(/"/g,'""')+'"');c.push(r.join(','));}dl('\uFEFF'+c.join('\n'),'text/csv;charset=utf-8;','.csv');}
function exportExcel(){var t=document.getElementById('resultTable');if(!t)return;dl('<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8"></head><body>'+t.outerHTML+'</body></html>','application/vnd.ms-excel','.xls');}
function dl(c,t,e){var b=new Blob([c],{type:t}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='cano_'+Date.now()+e;a.click();}
function esc(t){var d=document.createElement('div');d.appendChild(document.createTextNode(t));return d.innerHTML;}
function openModal(id){document.getElementById(id).classList.add('active');}
function closeModal(id){document.getElementById(id).classList.remove('active');}

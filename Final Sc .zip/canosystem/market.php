<?php
require_once __DIR__ . '/config/database.php';
initSession();
requireLogin();
$csrf = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fiyatlar - CANO SYSTEM</title>
    <link rel="icon" href="/assets/logo.jpg" type="image/jpeg">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="page-loader" id="pageLoader">
        <div style="text-align:center;"><div class="loader-spinner"></div><div class="loader-text">CANO SYSTEM</div></div>
    </div>

    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <?php include __DIR__ . '/includes/header.php'; ?>

    <main class="main-content" id="mainContent">
        <div class="content-inner fade-in">
            <div style="text-align:center;margin-bottom:32px;">
                <h2 style="font-size:24px;margin-bottom:6px;">💳 Premium Paketler</h2>
                <p style="color:var(--text-muted);font-size:14px;">Tüm premium sorgulara erişim için paket seçin</p>
            </div>

            <div class="pricing-grid">
                <!-- Aylık -->
                <div class="pricing-card">
                    <div class="pricing-name">AYLIK</div>
                    <div class="pricing-price">800<small>₺ / ay</small></div>
                    <div class="pricing-features">
                        <div class="feat"><span class="check">✓</span> Tüm Premium Sorgular</div>
                        <div class="feat"><span class="check">✓</span> Sınırsız Sorgu Hakkı</div>
                        <div class="feat"><span class="check">✓</span> Öncelikli Destek</div>
                        <div class="feat"><span class="check">✓</span> API Erişimi</div>
                    </div>
                    <a href="https://t.me/canodestekhat" target="_blank" class="btn btn-secondary btn-block">Satın Al</a>
                </div>

                <!-- 3 Aylık -->
                <div class="pricing-card popular">
                    <div class="pricing-badge">POPÜLER ⭐</div>
                    <div class="pricing-name">3 AYLIK</div>
                    <div class="pricing-price">1.300<small>₺ / 3 ay</small></div>
                    <div class="pricing-features">
                        <div class="feat"><span class="check">✓</span> Tüm Premium Sorgular</div>
                        <div class="feat"><span class="check">✓</span> Sınırsız Sorgu Hakkı</div>
                        <div class="feat"><span class="check">✓</span> Öncelikli Destek</div>
                        <div class="feat"><span class="check">✓</span> API Erişimi</div>
                        <div class="feat"><span class="check">✓</span> %46 Tasarruf</div>
                    </div>
                    <a href="https://t.me/canodestekhat" target="_blank" class="btn btn-primary btn-block">Satın Al</a>
                </div>

                <!-- Yıllık -->
                <div class="pricing-card">
                    <div class="pricing-name">YILLIK</div>
                    <div class="pricing-price">2.000<small>₺ / yıl</small></div>
                    <div class="pricing-features">
                        <div class="feat"><span class="check">✓</span> Tüm Premium Sorgular</div>
                        <div class="feat"><span class="check">✓</span> Sınırsız Sorgu Hakkı</div>
                        <div class="feat"><span class="check">✓</span> 7/24 VIP Destek</div>
                        <div class="feat"><span class="check">✓</span> API Erişimi</div>
                        <div class="feat"><span class="check">✓</span> %79 Tasarruf</div>
                    </div>
                    <a href="https://t.me/canodestekhat" target="_blank" class="btn btn-secondary btn-block">Satın Al</a>
                </div>

                <!-- Sınırsız -->
                <div class="pricing-card">
                    <div class="pricing-name">SINIRSIZ</div>
                    <div class="pricing-price">3.000<small>₺ tek sefer</small></div>
                    <div class="pricing-features">
                        <div class="feat"><span class="check">✓</span> Tüm Premium Sorgular</div>
                        <div class="feat"><span class="check">✓</span> Ömür Boyu Erişim</div>
                        <div class="feat"><span class="check">✓</span> 7/24 VIP Destek</div>
                        <div class="feat"><span class="check">✓</span> API Erişimi</div>
                        <div class="feat"><span class="check">✓</span> Tüm Güncellemeler</div>
                    </div>
                    <a href="https://t.me/canodestekhat" target="_blank" class="btn btn-secondary btn-block">Satın Al</a>
                </div>
            </div>

            <!-- FAQ -->
            <h3 style="font-size:20px;margin-bottom:16px;">❓ Sıkça Sorulan Sorular</h3>
            <div class="faq-list">
                <div class="faq-item">
                    <div class="faq-question">💳 Ödeme nasıl yapılır?<span class="faq-toggle">+</span></div>
                    <div class="faq-answer">Telegram üzerinden @canodestekhat ile iletişime geçerek ödeme yöntemi hakkında bilgi alabilirsiniz.</div>
                </div>
                <div class="faq-item">
                    <div class="faq-question">♻️ Paket değiştirebilir miyim?<span class="faq-toggle">+</span></div>
                    <div class="faq-answer">Evet, istediğiniz zaman daha yüksek pakete geçebilirsiniz.</div>
                </div>
                <div class="faq-item">
                    <div class="faq-question">↩️ İptal etmek istersem?<span class="faq-toggle">+</span></div>
                    <div class="faq-answer">Desteğimize başvurarak paketinizi iptal edebilirsiniz. Şartlar paket türüne göre değişir.</div>
                </div>
                <div class="faq-item">
                    <div class="faq-question">🛠️ Teknik destek var mı?<span class="faq-toggle">+</span></div>
                    <div class="faq-answer">Evet, Premium üyeler 24/7 teknik destek alabilirler. Telegram veya email üzerinden destek sunuyoruz.</div>
                </div>
            </div>

            <!-- Contact CTA -->
            <div class="contact-cta">
                <h3>📞 Destek için İletişime Geçin</h3>
                <p>Herhangi sorunuz varsa lütfen Telegram'dan bize yazın:</p>
                <a href="https://t.me/canodestekhat" target="_blank" class="btn btn-telegram" style="font-size:16px;padding:14px 32px;">💬 DESTEK: @CANODESTEKHAT</a>
            </div>
        </div>
    </main>

    <script src="/assets/js/main.js"></script>
</body>
</html>

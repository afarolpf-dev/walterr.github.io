<?php
require_once __DIR__ . '/config/database.php';
initSession();
requireLogin();

$type = $_GET['type'] ?? '';
$csrf = generateCSRFToken();

$queries = [
    'tc' => ['title' => 'TC Sorgu', 'fields' => [['tc','TC Numarası','11 haneli TC giriniz', true]], 'note' => ''],
    'adsoyad' => ['title' => 'Ad Soyad Sorgu', 'fields' => [['ad','Ad','Ad giriniz', true],['soyad','Soyad','Soyad giriniz', true],['il','İl','İl giriniz', false],['ilce','İlçe','İlçe giriniz', false]], 'note' => 'İl ve İlçe zorunlu değildir.'],
    'aile' => ['title' => 'Aile Sorgusu', 'fields' => [['tc','TC Numarası','11 haneli TC giriniz', true]], 'note' => ''],
    'sulale' => ['title' => 'Şecere (Sulale)', 'fields' => [['tc','TC Numarası','11 haneli TC giriniz', true]], 'note' => ''],
    'es' => ['title' => 'Eş Sorgusu', 'fields' => [['tc','TC Numarası','11 haneli TC giriniz', true]], 'note' => ''],
    'cocuk' => ['title' => 'Çocuk Sorgusu', 'fields' => [['tc','TC Numarası','11 haneli TC giriniz', true]], 'note' => ''],
    'anne' => ['title' => 'Anne Sorgusu', 'fields' => [['tc','TC Numarası','11 haneli TC giriniz', true]], 'note' => ''],
    'baba' => ['title' => 'Baba Sorgusu', 'fields' => [['tc','TC Numarası','11 haneli TC giriniz', true]], 'note' => ''],
    'tcgsm' => ['title' => 'TC → GSM', 'fields' => [['tc','TC Numarası','11 haneli TC giriniz', true]], 'note' => ''],
    'gsmtc' => ['title' => 'GSM → TC', 'fields' => [['gsm','GSM Numarası','GSM numarası giriniz', true]], 'note' => ''],
];

if (!isset($queries[$type])) {
    header('Location: /dashboard.php');
    exit;
}

$q = $queries[$type];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($q['title']) ?> - CANO SYSTEM</title>
    <link rel="icon" href="/assets/logo.jpg" type="image/jpeg">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="page-loader" id="pageLoader">
        <div style="text-align:center;"><div class="loader-spinner"></div><div class="loader-text">CANO SYSTEM</div></div>
    </div>

    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <?php include __DIR__ . '/includes/header.php'; ?>

    <main class="main-content" id="mainContent">
        <div class="content-inner fade-in" style="max-width:800px;">
            <h2 style="font-size:20px;margin-bottom:20px;display:flex;align-items:center;gap:10px;">
                🔍 <?= sanitize($q['title']) ?>
            </h2>

            <div class="card query-form" style="margin-bottom:20px;padding:20px;">
                <form id="queryForm" action="/api/query.php" method="POST" onsubmit="event.preventDefault();doQuery('queryForm','queryResult');">
                    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                    <input type="hidden" name="type" value="<?= sanitize($type) ?>">

                    <div class="form-row">
                        <?php foreach ($q['fields'] as $f): ?>
                        <div class="form-group" style="margin-bottom:10px;">
                            <label style="font-size:11px;"><?= sanitize($f[1]) ?> <?= !$f[3] ? '<span style="color:var(--text-muted);font-weight:400;">(opsiyonel)</span>' : '' ?></label>
                            <input type="text" name="<?= $f[0] ?>" class="form-input" style="padding:11px 14px;font-size:14px;" placeholder="<?= sanitize($f[2]) ?>" <?= count($q['fields']) <= 2 ? 'autofocus' : '' ?>>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <?php if ($q['note']): ?>
                    <p style="color:var(--text-muted);font-size:12px;margin-bottom:12px;">ℹ️ <?= $q['note'] ?></p>
                    <?php endif; ?>

                    <button type="submit" class="btn btn-primary" style="max-width:200px;padding:11px 20px;font-size:13px;">🔍 SORGU YAP</button>
                </form>
            </div>

            <div class="card query-result" id="queryResult" style="padding:20px;">
                <div class="no-result" style="color:var(--text-muted);font-size:13px;">Sorgu sonuçları burada görünecek</div>
            </div>
        </div>
    </main>

    <script src="/assets/js/main.js"></script>
</body>
</html>

<?php
require_once __DIR__ . '/config/database.php';
initSession(); requireLogin();
$db = getDB(); $userId = $_SESSION['user_id'];
$stmt = $db->prepare("SELECT * FROM users WHERE id=:id"); $stmt->execute([':id'=>$userId]); $user = $stmt->fetch();
if(!$user){session_destroy();header('Location: /index.php');exit;}
$totalQueries = $user['total_queries'] ?? 0;
$hour=(int)date('G');
if($hour<6)$greeting='İyi Geceler';elseif($hour<12)$greeting='İyi Sabahlar';elseif($hour<18)$greeting='İyi Günler';else $greeting='İyi Akşamlar';
$premiumText='—';
if($user['user_type']==='admin')$premiumText='Sınırsız';
elseif($user['premium_until'])$premiumText=date('d.m.Y',strtotime($user['premium_until']));
$csrf=generateCSRFToken();
$showTgPopup = false;
if (!isset($_SESSION['tg_popup_shown'])) { $showTgPopup = true; $_SESSION['tg_popup_shown'] = true; }
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>Dashboard - CANO SYSTEM | Bedava Sorgu Paneli 2026</title>
    <meta name="description" content="CANO SYSTEM - Türkiye'nin en gelişmiş bedava sorgu paneli.">
    <link rel="icon" href="/assets/logo.jpg" type="image/jpeg">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="page-loader" id="pageLoader"><div style="text-align:center;"><div class="loader-spinner"></div><div class="loader-text">CANO SYSTEM</div></div></div>

    <?php include __DIR__.'/includes/sidebar.php'; ?>
    <?php include __DIR__.'/includes/header.php'; ?>
    <main class="main-content" id="mainContent">
        <div class="content-inner fade-up">
            <div class="greeting">
                <h2><?=$greeting?>, <span><?=sanitize($user['username'])?></span></h2>
                <p>CANO SYSTEM kontrol panelinize hoş geldiniz. Sorgulamak için ☰ menüyü kullanın.</p>
            </div>
            <div class="stats-grid">
                <div class="stat-card sc-green"><div class="stat-icon">👑</div><div class="stat-label">Üyelik</div><div class="stat-value" style="color:#00ffaa;"><?=strtoupper($user['user_type'])?></div></div>
                <div class="stat-card sc-blue"><div class="stat-icon">📅</div><div class="stat-label">Premium Bitiş</div><div class="stat-value" style="color:#00c8ff;"><?=$premiumText?></div></div>
                <div class="stat-card sc-purple"><div class="stat-icon">🔍</div><div class="stat-label">Toplam Sorgu</div><div class="stat-value" style="color:#a855f7;"><?=$totalQueries?></div></div>
                <div class="stat-card sc-orange"><div class="stat-icon">⚡</div><div class="stat-label">Sistem</div><div class="stat-value" style="color:#ff9f1c;">AKTİF</div></div>
            </div>
            <div class="cta-card">
                <div class="cta-inner">
                    <div><h3>Telegram Kanalımız</h3><p>Güncellemeler ve destek için katılın</p></div>
                    <a href="https://t.me/+Wcqw6y5Z14s5Njg1" target="_blank" class="btn btn-telegram">✈️ Kanala Katıl</a>
                </div>
            </div>
        </div>
    </main>

    <?php if($showTgPopup): ?>
    <div class="tg-popup-overlay" id="tgPopup">
        <div class="tg-popup">
            <button class="tg-popup-close" onclick="document.getElementById('tgPopup').style.display='none'">✕</button>
            <div class="tg-popup-icon">✈️</div>
            <h3>Duyurulardan Eksik Kalmamak İçin Kanalımıza Katıl</h3>
            <p>Sistem kurallarından ve güncellemelerden anında haberdar olmak için resmi topluluğumuza <strong>katılmanız zorunludur.</strong></p>
            <a href="https://t.me/+Wcqw6y5Z14s5Njg1" target="_blank" class="btn btn-tg-join" onclick="document.getElementById('tgPopup').style.display='none'">✈️ Telegram'a Katıl</a>
        </div>
    </div>
    <?php endif; ?>

    <script src="/assets/js/main.js"></script>
</body>
</html>

<?php
require_once __DIR__ . '/../config/database.php';
initSession();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { jsonResponse(['status' => false, 'mesaj' => 'Method not allowed'], 405); }
requireLogin();

$token = $_POST['csrf_token'] ?? '';
if (!verifyCSRFToken($token)) { jsonResponse(['status' => false, 'mesaj' => 'Güvenlik hatası'], 403); }

$type = $_POST['type'] ?? '';
$db = getDB();

$apiMap = [
    'tc'      => ['endpoint' => '/tc.php', 'params' => ['tc']],
    'adsoyad' => ['endpoint' => '/adsoyad.php', 'params' => ['ad','soyad','il','ilce']],
    'aile'    => ['endpoint' => '/aile.php', 'params' => ['tc']],
    'sulale'  => ['endpoint' => '/sulale.php', 'params' => ['tc']],
    'es'      => ['endpoint' => '/es.php', 'params' => ['tc']],
    'cocuk'   => ['endpoint' => '/cocuk.php', 'params' => ['tc']],
    'anne'    => ['endpoint' => '/anne.php', 'params' => ['tc']],
    'baba'    => ['endpoint' => '/baba.php', 'params' => ['tc']],
    'tcgsm'   => ['endpoint' => '/tcgsm.php', 'params' => ['tc']],
    'gsmtc'   => ['endpoint' => '/gsmtc.php', 'params' => ['gsm']],
];

if (!isset($apiMap[$type])) {
    jsonResponse(['status' => false, 'mesaj' => 'Geçersiz sorgu tipi']);
}

$map = $apiMap[$type];

$queryParams = [];
foreach ($map['params'] as $p) {
    $val = trim($_POST[$p] ?? '');
    if ($val !== '') {
        $queryParams[$p] = $val;
    }
}

// First param is required (except adsoyad where ad+soyad needed)
if ($type === 'adsoyad') {
    if (empty($queryParams['ad']) && empty($queryParams['soyad'])) {
        jsonResponse(['status' => false, 'mesaj' => 'Ad veya Soyad gerekli']);
    }
} else {
    $required = $map['params'][0];
    if (empty($queryParams[$required])) {
        jsonResponse(['status' => false, 'mesaj' => 'Zorunlu alan boş bırakılamaz']);
    }
}

$apiUrl = API_BASE_URL . $map['endpoint'] . '?' . http_build_query($queryParams);
$apiUrl .= '&key=' . urlencode(API_KEY);

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $apiUrl,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_USERAGENT => 'CANOSYSTEM/2.0',
    CURLOPT_HTTPHEADER => ['Accept: application/json'],
]);

$response = curl_exec($ch);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError || !$response) {
    jsonResponse(['status' => false, 'mesaj' => 'API bağlantı hatası']);
}

$data = json_decode($response, true);
if (!$data) {
    jsonResponse(['status' => false, 'mesaj' => 'API yanıt hatası']);
}

// Log query
$ip = getClientIP();
try {
    $logStmt = $db->prepare("INSERT INTO query_logs (user_id, query_type, query_data, ip_address) VALUES (:uid, :type, :data, :ip)");
    $logStmt->execute([':uid' => $_SESSION['user_id'], ':type' => $type, ':data' => json_encode($queryParams, JSON_UNESCAPED_UNICODE), ':ip' => $ip]);
    $db->prepare("UPDATE users SET total_queries = total_queries + 1 WHERE id = :id")->execute([':id' => $_SESSION['user_id']]);
} catch (Exception $e) {}

// Remove fields we don't want
unset($data['sure'], $data['api_by'], $data['kalan_sorgu']);

// Normalize response based on type so JS can handle it uniformly
// We'll send back: { status, mesaj, sonuc (object or array), type }
$normalized = ['status' => $data['status'] ?? true, 'mesaj' => $data['mesaj'] ?? '', 'type' => $type];

switch ($type) {
    case 'tc':
        // sonuc is already a flat object
        $normalized['sonuc'] = $data['sonuc'] ?? [];
        $normalized['format'] = 'single';
        break;

    case 'adsoyad':
        // sonuclar is an array
        $normalized['sonuc'] = $data['sonuclar'] ?? [];
        $normalized['format'] = 'table';
        break;

    case 'aile':
        // aile is an array
        $normalized['sonuc'] = $data['aile'] ?? [];
        $normalized['format'] = 'table';
        break;

    case 'sulale':
        // sulale is nested object with kendisi, anne, baba, kardesler[], cocuklar[], etc
        $sulale = $data['sulale'] ?? [];
        $flat = [];
        // Flatten into a single table
        $sections = [
            'kendisi' => 'KENDİSİ',
            'anne' => 'ANNE',
            'baba' => 'BABA',
            'baba_taraf_dede' => 'DEDE (BABA)',
            'babaanne' => 'BABAANNE',
            'anne_taraf_dede' => 'DEDE (ANNE)',
            'anneanne' => 'ANNEANNE',
        ];
        foreach ($sections as $key => $label) {
            if (isset($sulale[$key]) && is_array($sulale[$key]) && !empty($sulale[$key])) {
                $row = $sulale[$key];
                $row['YAKINLIK'] = $label;
                $flat[] = $row;
            }
        }
        $arrays = [
            'kardesler' => 'KARDEŞ',
            'cocuklar' => 'ÇOCUK',
            'amca_hala' => 'AMCA/HALA',
            'dayi_teyze' => 'DAYI/TEYZE',
        ];
        foreach ($arrays as $key => $label) {
            if (isset($sulale[$key]) && is_array($sulale[$key])) {
                foreach ($sulale[$key] as $item) {
                    $item['YAKINLIK'] = $label;
                    $flat[] = $item;
                }
            }
        }
        $normalized['sonuc'] = $flat;
        $normalized['format'] = 'table';
        break;

    case 'es':
        // esler is an array
        $normalized['sonuc'] = $data['esler'] ?? [];
        $normalized['format'] = 'table';
        break;

    case 'cocuk':
        // cocuklar is an array
        $normalized['sonuc'] = $data['cocuklar'] ?? [];
        $normalized['format'] = 'table';
        break;

    case 'anne':
        // anne is a flat object
        $normalized['sonuc'] = $data['anne'] ?? [];
        $normalized['format'] = 'single';
        break;

    case 'baba':
        // baba is a flat object
        $normalized['sonuc'] = $data['baba'] ?? [];
        $normalized['format'] = 'single';
        break;

    case 'tcgsm':
        // sonuc has TC, numaralar array, etc
        $s = $data['sonuc'] ?? [];
        if (isset($s['numaralar']) && is_array($s['numaralar'])) {
            $s['GSM_NUMARALARI'] = implode(', ', $s['numaralar']);
            unset($s['numaralar'], $s['gsm_sayisi']);
        }
        $normalized['sonuc'] = $s;
        $normalized['format'] = 'single';
        break;

    case 'gsmtc':
        // sonuclar is an array
        $normalized['sonuc'] = $data['sonuclar'] ?? [];
        $normalized['format'] = 'table';
        break;

    default:
        $normalized['sonuc'] = $data['sonuc'] ?? $data;
        $normalized['format'] = 'single';
}

jsonResponse($normalized);
